package com.example.umang.notification;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.app.NotificationChannel;

public class MainActivity extends AppCompatActivity {
    Button  btn;
    private NotificationHelper notificationHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("Test","Phase 0");
        btn=(Button)findViewById(R.id.button);
        notificationHelper=new NotificationHelper(this);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               NotificationCompat.Builder nb=notificationHelper.getChannelNotification();
               notificationHelper.getNotificationManager().notify(1,nb.build());




            }
        });
    }


    }



